import mysql.connector
from selenium import webdriver


base_url = "https://www.mca.gov.in/bin/dms/searchDocList?page=1&perPage=799&sortField=Date&sortOrder=D&searchField=Title&searchKeyword=&startDate=&endDate=&filter=&dialog=%7B%22folder%22%3A%22441%22%2C%22language%22%3A%22English%22%2C%22totalColumns%22%3A3%2C%22columns%22%3A%5B%22Title%22%2C%22ROC%22%2C%22Date%22%5D%7D"
excel_file_path = r"C:\Users\magudapathy.7409\Desktop\Mca_ROC\output.xlsx"


chrome_options = webdriver.ChromeOptions()
browser = webdriver.Chrome(options=chrome_options)

log_list = [None] * 3

source_status = "Active"
no_data_avaliable = 0
no_data_scraped = 0
source_name = "mca_roc"
updated_count = 0

db_host = '127.0.0.1'
db_user = 'root'
db_password = 'root'
db_name = 'mbie'
table_name = 'mca_orders'

def db_connection():
    connection = mysql.connector.connect(
        host=db_host,
        user=db_user,
        password=db_password,
        database=db_name
    )
    return connection




