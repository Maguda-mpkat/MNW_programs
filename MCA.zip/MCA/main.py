from config import mca_config
import sys
from functions.get_data_count import get_data_count
from functions.extractdata_from_website import extract_data_from_website
from functions.insert_log_into_table import insert_log_into_table

log_cursor =  mca_config.db_connection()


def main():
    if mca_config.source_status == "Active":
        extract_data_from_website()
    elif mca_config.source_status == "Hibernated":
        mca_config.log_list[0] = "not run"
        insert_log_into_table(mca_config.log_list)
        mca_config.log_list = [None] * 3
        sys.exit()
    elif mca_config.source_status == "Inactive":
        mca_config.log_list[0] = "not run"
        insert_log_into_table(mca_config.log_list)
        mca_config.log_list = [None] * 3
        sys.exit()

if __name__ == "__main__":                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     
    main()