from config import mca_config
from functions import get_data_count


def insert_log_into_table(log_list):
    conneciton =  mca_config.db_connection()
    cursor = conneciton.cursor()

    query = """
        INSERT INTO mca_log (source_name, script_status, data_available, data_scraped, total_record_count, failure_reason, comments, updated_count, source_status)
        VALUES (%(source_name)s, %(script_status)s, %(data_available)s, %(data_scraped)s, %(total_record_count)s, %(failure_reason)s, %(comments)s, %(updated_count)s, %(source_status)s)
    """
    values = {
        'source_name': mca_config.source_name,
        'script_status': log_list[0] if log_list[0] else None,
        'data_available': mca_config.no_data_avaliable,
        'data_scraped': mca_config.no_data_scraped,
        'total_record_count': get_data_count.get_data_count(),
        'failure_reason': log_list[1] if log_list[1] else None,
        'comments': log_list[2] if log_list[2] else None,
        'updated_count': mca_config.updated_count,
        'source_status': mca_config.source_status
    }
    
    print("log list ======", values)
    cursor.execute(query, values)
    conneciton.commit()