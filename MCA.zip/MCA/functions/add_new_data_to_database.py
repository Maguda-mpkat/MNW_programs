import sys
import pandas as pd
import traceback
from datetime import datetime
from config import mca_config
from sqlalchemy import create_engine
from functions.get_data_count import get_data_count
from functions.insert_log_into_table import insert_log_into_table
from functions.download_pdf_files import download_pdf_files
from functions.updated_rows import updts


def add_new_data_to_database( excel_file_path, db_table_name):
    try:
        database_uri = f'mysql://{mca_config.db_user}:{mca_config.db_password}@{mca_config.db_host}/{mca_config.db_name}'
        engine = create_engine(database_uri)
        print("engine",engine)
        columns_to_select = ['link_to_order']
        select_query = f"SELECT {', '.join(columns_to_select)} FROM {db_table_name};"
        database_table_df = pd.read_sql(select_query, con=engine)
        print("database_table_df",database_table_df)
        excel_data_df = pd.read_excel(excel_file_path)
        print("excel_data_df",excel_data_df)
        excel_data_df = excel_data_df.drop_duplicates(subset=['link_to_order'])
        
        missing_rows_in_db = []
        print(missing_rows_in_db,"missing_rows_in_db")
        for index, row in excel_data_df.iterrows():
            if row["link_to_order"] not in database_table_df["link_to_order"].values:
                missing_rows_in_db.append(row)
                mca_config.no_data_avaliable += 1


        if  missing_rows_in_db:
            print("Rows from Excel Data not in Database Table")
            print("missing rows in DB",missing_rows_in_db)

            # Save missing rows to a new Excel sheet with the current date as the filename
            current_date = datetime.now().strftime("%Y-%m-%d")
            new_excel_file_path = rf"C:\Users\magudapathy.7409\Desktop\MCA\incremental_excel_sheets\Missing_Data_{current_date}.xlsx"
            df = pd.DataFrame(missing_rows_in_db)
            df.to_excel(new_excel_file_path, index=False)

            print(f"Missing rows saved to {new_excel_file_path}")

            updts(r"C:\Users\magudapathy.7409\Desktop\MCA\output.xlsx")
            download_pdf_files(new_excel_file_path)
           

        else:
            traceback.print_exc()
            mca_config.log_list[0] = "Failure"
            mca_config.log_list[1] = "script error"
            insert_log_into_table(mca_config.log_list)
            mca_config.log_list = [None] * 3
            sys.exit("script error")

    except Exception as e:
        traceback.print_exc()
        mca_config.log_list[0] = "Failure"
        mca_config.log_list[1] = "script error"
        insert_log_into_table(mca_config.log_list)
        mca_config.log_list = [None] * 3
        sys.exit("script error")