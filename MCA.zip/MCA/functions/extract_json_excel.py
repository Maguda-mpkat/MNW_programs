import json
import pandas as pd
import sys
import traceback
from urllib.parse import quote
from config import mca_config
from functions.get_data_count import get_data_count
from functions.insert_log_into_table import insert_log_into_table
from functions.add_new_data_to_database import add_new_data_to_database


def extract_json_excel():
    try:
        # Specify the path to your JSON file in ".txt" format
        json_file_path = r"C:\Users\magudapathy.7409\Desktop\Mca_ROC\webpage.txt"

        # Read JSON data from the file
        with open(json_file_path, "r") as json_file:
            json_data = json.load(json_file)

        # Extract the "documentDetails" value and convert it to a list
        document_details_str = json_data.get("documentDetails", "[]")
        document_details_list = json.loads(document_details_str)

        # Create a DataFrame from the list of dictionaries
        df = pd.DataFrame(document_details_list).fillna('')

        # Select only the desired columns
        selected_columns = ['column1', 'column2', 'docDate', 'docID']
        df = df[selected_columns]

        # Rename the columns
        df = df.rename(columns={
            'column1': 'title_of_order',
            'column2': 'ROC_RD_LOCATION',
            'docDate': 'date_of_order',
            'docID': 'Encoded_Id'
        })

        # Add a new column named "Type" with the value "ROC"
        df['type_of_order'] = 'ROC'
        df['updated_date'] = None


        # Rearrange the columns to place "Type" after "File_name"
        df = df[['title_of_order', 'type_of_order', 'ROC_RD_LOCATION', 'date_of_order', 'Encoded_Id','updated_date']]

        # Create the 'link' column
        df['link_to_order'] = df['Encoded_Id'].apply(lambda x: f"https://www.mca.gov.in/bin/dms/getdocument?mds={quote(x)}&type=open")

        # Specify the Excel file name
        excel_file_name = "output.xlsx"

        # Write the DataFrame to an Excel file
        df.to_excel(excel_file_name, index=False)

        print(f"Data has been successfully written to {excel_file_name}")
        excel_file_path = mca_config.excel_file_path
        table_name = mca_config.table_name

        # Download PDF files
        add_new_data_to_database(excel_file_path,table_name) # to compare the database table and incremental excel sheet
    except Exception as e :
        traceback.print_exc()
        mca_config.log_list[0] = "Failure"
        mca_config.log_list[1] = "script error"
        insert_log_into_table(mca_config.log_list)
        mca_config.log_list = [None] * 3
        sys.exit("script error")