import pandas as pd
from config import mca_config
import sys
import traceback
from functions.insert_log_into_table import insert_log_into_table

def insert_into_database(excel_file_path):
    conneciton =  mca_config.db_connection()
    cursor = conneciton.cursor()

    try:
        df = pd.read_excel(excel_file_path, sheet_name='Sheet1', engine='openpyxl')
        df = df.where(pd.notnull(df), None)




        for index, row in df.iterrows():
            insert_query = f"""
                INSERT INTO {mca_config.table_name} (title_of_order, type_of_order, ROC_RD_LOCATION, date_of_order, link_to_order, pdf_file_path, pdf_file_name)
                VALUES (%s, %s, %s, %s, %s, %s, %s)
            """
            values = (row['title_of_order'], row['type_of_order'], row['ROC_RD_LOCATION'], row['date_of_order'], row['link_to_order'], row['pdf_file_path'], row['pdf_file_name'])
            cursor.execute(insert_query, values)
            conneciton.commit()
            mca_config.no_data_scraped += 1

        print(f"Data has been successfully inserted into the '{mca_config.table_name}' table in the database.")
        
        mca_config.log_list[0] = "Success"
        mca_config.log_list[2] = f"{mca_config.no_data_scraped} data scraped, {mca_config.updated_count} data updated"
        insert_log_into_table(mca_config.log_list)
        mca_config.log_list = [None] * 3

    except Exception as e:  
        traceback.print_exc()
        mca_config.log_list[0] = "Failure"
        mca_config.log_list[1] = "script error"
        insert_log_into_table(mca_config.log_list)
        mca_config.log_list = [None] * 3
        sys.exit("script error")


