from config import mca_config

def get_data_count():

    connection = mca_config.db_connection()
    cursor = connection.cursor()
    with connection.cursor() as db_cursor:
        db_cursor.execute(f"SELECT COUNT(*) FROM {mca_config.table_name} WHERE type_of_order = 'ROC'")
        total_rows = db_cursor.fetchone()[0]
    return total_rows
