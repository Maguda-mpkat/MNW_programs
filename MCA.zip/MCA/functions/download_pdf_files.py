import os
import pandas as pd
import requests
import re
from config import mca_config
from datetime import datetime
import traceback
from functions.get_data_count import get_data_count
import sys
from functions.insert_log_into_table import insert_log_into_table
from functions.insert_into_database import insert_into_database


def download_pdf_files(excel_file_path, download_folder=r"C:\Users\magudapathy.7409\Desktop\Mca_ROC\downloaded_documents"):
    try:
        # Create the download folder if it doesn't exist
        if not os.path.exists(download_folder):
            os.makedirs(download_folder)

        # Read the Excel file to get the links
        df = pd.read_excel(excel_file_path)
        links = df['link_to_order']

        # Custom headers
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
        }

        # Loop through each row in the DataFrame
        for index, link in enumerate(links, start=1):
            try:
                # Make a request to download the document with User-Agent header
                response = requests.get(link, headers=headers)

                if response.status_code == 200:
                    content_disposition = response.headers.get('content-disposition')

                    if content_disposition:
                        match = re.search(r'filename="(.+)"', content_disposition)
                        if match:
                            original_filename = match.group(1)
                        else:
                            original_filename = f"document_{index}.pdf"
                    else:
                        original_filename = f"document_{index}.pdf"

                    # Ensure the file extension is PDF
                    if not original_filename.lower().endswith('.pdf'):
                        original_filename += '.pdf'
                       
                    # Get the month and year from the 'date_of_order' column
                    day, month, year = map(int, df.at[index - 1, 'date_of_order'].split('-'))
                    month_name = datetime(year, month, day).strftime('%B')
                    year_folder = str(year)
                    month_year_folder = os.path.join(year_folder, month_name)
                    file_folder = os.path.join(download_folder, month_year_folder)
                    if not os.path.exists(file_folder):
                        os.makedirs(file_folder)

                    # Check for existing files and create a unique filename if necessary
                    base_filename, extension = os.path.splitext(original_filename)
                    unique_filename = original_filename
                    counter = 1
                    while os.path.exists(os.path.join(file_folder, unique_filename)):
                        unique_filename = f"{base_filename}({counter}){extension}"
                        counter += 1

                    # Save the document in the new folder with the unique filename
                    file_name = os.path.join(file_folder, unique_filename)
                    with open(file_name, 'wb') as file:
                        file.write(response.content)

                    # Update DataFrame with file name and path
                    pdf_file_name = os.path.splitext(unique_filename)[0]  # Extract file name without extension
                    df.at[index-1, 'pdf_file_name'] = pdf_file_name  # Indexing in DataFrame is 0-based
                    df.at[index-1, 'pdf_file_path'] = file_name

                    # Print status
                    print(f"Document {index}/{len(links)} downloaded successfully: {file_name}")
                else:
                    print(f"Failed to download file {index}/{len(links)} from link: {link}")
            except Exception as e:
                print(f"An error occurred while downloading file {index}/{len(links)}: {str(e)}")
                traceback.print_exc()
                mca_config.log_list[0] = "Failure"
                mca_config.log_list[1] = "script error"
                insert_log_into_table(mca_config.log_list)
                mca_config.log_list = [None] * 3
                sys.exit("script error")

        # Save the updated DataFrame back to the Excel file
        df.to_excel(excel_file_path, index=False)
        insert_into_database(excel_file_path)
        print("Excel file updated with pdf_file_name and pdf_file_path columns.")

    except Exception as e:
        traceback.print_exc()
        mca_config.log_list[0] = "Failure"
        mca_config.log_list[1] = "script error"
        insert_log_into_table(mca_config.log_list)
        mca_config.log_list = [None] * 3
        sys.exit("script error")
