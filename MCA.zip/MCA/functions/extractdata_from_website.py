
from config import mca_config
from bs4 import BeautifulSoup
import time
import json
import sys
from selenium import webdriver
import traceback
from functions.get_data_count import get_data_count
from functions.extract_json_excel import extract_json_excel
from functions.insert_log_into_table import insert_log_into_table


def extract_data_from_website():
    try:
   

       
        mca_config.browser.get(mca_config.base_url) # Default perPage value is set to 5
        time.sleep(10)

        # Get the page source
        page_source = mca_config.browser.page_source
        print(page_source)

        # Close the browser
        mca_config.browser.quit()

        # Extract JSON data from HTML using BeautifulSoup
        soup = BeautifulSoup(page_source, 'html.parser')
        print(soup)
        json_data = soup.find('pre').text
   
    except Exception as e :
        traceback.print_exc()
        mca_config.log_list[0] = "Failure"
        mca_config.log_list[1] = "script error"
        insert_log_into_table(mca_config.log_list)
        mca_config.log_list = [None] * 3
        sys.exit("script error")
   

    # Save the extracted JSON data to a text file
    with open("webpage.txt", "w", encoding="utf-8") as file:
        file.write(json_data)

    # Read the JSON data from the file
    with open("webpage.txt", "r", encoding="utf-8") as file:
        json_data = file.read()

    # Parse the JSON data
    data = json.loads(json_data)

    # Extract and print the count associated with 'totalResults' key
    total_results_count = data.get('totalResults', 0)
    print(f'The totalResults count is: {total_results_count}')

    # Get the total count of rows in the table
    cursor_2 = mca_config.db_connection()
    cursor= cursor_2.cursor()
    cursor.execute(f"SELECT COUNT(*) FROM {mca_config.table_name} WHERE type_of_order = 'ROC'")
    total_rows = cursor.fetchone()[0]
    cursor.close()


    print(f'The total number of rows in {mca_config.table_name} table is: {total_rows}')
    result_dict = {'total_rows': total_rows}

    # Check if the total number of rows in the table is less than totalResults count
    if total_rows < total_results_count:
       
        no_data_avaliable = total_results_count - total_rows
        print("Updating URL with totalResults count...")
       
        # Update the URL with the totalResults count

        try:
            chrome_options = webdriver.ChromeOptions()
            browser = webdriver.Chrome(options=chrome_options)
            browser.maximize_window()
            # Use the updated URL to fetch JSON data

            browser.get(mca_config.base_url)
            time.sleep(10)
           
            # Get the page source
            updated_page_source = browser.page_source
           
            # Close the browser
            mca_config.browser.quit()
        except Exception as e :
            traceback.print_exc()
            mca_config.log_list[0] = "Failure"
            mca_config.log_list[1] = "script error"
            insert_log_into_table(mca_config.log_list)
            mca_config.log_list = [None] * 3
            sys.exit("script error")
           
        # Extract JSON data from the updated HTML
        updated_soup = BeautifulSoup(updated_page_source, 'html.parser')
        updated_json_data = updated_soup.find('pre').text
       
        # Save the updated JSON data to a text file
        with open("webpage.txt", "w", encoding="utf-8") as file:
            file.write(updated_json_data)
       
        print("Updated JSON data saved to webpage.txt")

        extract_json_excel()
       
    else:
        print("no new data found")
        mca_config.log_list[1] = "Success"
        mca_config.log_list[2] = "no new data found"
        insert_log_into_table(mca_config.log_list)
        mca_config.log_list = [None] * 3
        sys.exit("there is no new data")