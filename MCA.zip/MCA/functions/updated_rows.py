
import pandas as pd
from config import mca_config
from sqlalchemy import create_engine
from datetime import datetime
import traceback
import sys
from functions.insert_log_into_table import insert_log_into_table

def updated_data_into_database_table(updated_rows_in_db, updated_rows_in_excel):

    conneciton =  mca_config.db_connection()
    cursor = conneciton.cursor()
    print("updated_data_into_database_table function is called")
    try:
        count = 0
        for db_row, excel_row in zip(updated_rows_in_db, updated_rows_in_excel):
            current_timestamp = datetime.now().strftime('%Y-%m-%d %H:%M:%S')

            # Check if each relevant field has changed and build the update query accordingly
            fields_to_update = []
            values = []
            
            if db_row["title_of_order"] != excel_row["title_of_order"]:
                fields_to_update.append("title_of_order = %s")
                values.append(excel_row["title_of_order"])

            if db_row["ROC_RD_LOCATION"] != excel_row["ROC_RD_LOCATION"]:
                fields_to_update.append("ROC_RD_LOCATION = %s")
                values.append(excel_row["ROC_RD_LOCATION"])

            if fields_to_update:
                fields_to_update.append("updated_date = %s")
                values.append(current_timestamp)
                values.append(db_row["link_to_order"])

                update_query = f"""
                    UPDATE {mca_config.table_name}
                    SET {", ".join(fields_to_update)}
                    WHERE link_to_order = %s
                """
                cursor.execute(update_query, values)
                count += 1
          
        
            
        conneciton.commit()
        print("updated_data_into_database_table finished")
        return count
    
        
    except Exception as e:
            traceback.print_exc()
            mca_config.log_list[0] = "Failure"
            mca_config.log_list[1] = "script error"
            insert_log_into_table(mca_config.log_list)
            mca_config.log_list = [None] * 3
            sys.exit("script error")


def updts(excel_file_path):

        database_uri = f'mysql://{mca_config.db_user}:{mca_config.db_password}@{mca_config.db_host}/{mca_config.db_name}'
        engine = create_engine(database_uri)

        columns_to_select = ['title_of_order','ROC_RD_LOCATION','link_to_order']
        select_query = f"SELECT {', '.join(columns_to_select)} FROM {mca_config.table_name};"
        database_table_df = pd.read_sql(select_query, con=engine)
        excel_data_df = pd.read_excel(excel_file_path)
        
        updated_rows_in_db = []
        updated_rows_in_excel = []

        database_df = database_table_df.reset_index(drop=True)
        print("Database Columns:", database_table_df.columns)
        excel_df = excel_data_df.reset_index(drop=True)
        print("Excel Columns:", excel_data_df.columns)


        for index, db_row in database_df.iterrows():
            excel_row = excel_df[excel_df["link_to_order"] == db_row["link_to_order"]]
            if not excel_row.empty:
                excel_row = excel_row.iloc[0]


                db_row_normalized = db_row.copy()
                excel_row_normalized = excel_row.copy()


                for col in ["title_of_order", "ROC_RD_LOCATION", "link_to_order"]:
                    db_row_normalized[col] = db_row_normalized[col] if pd.isnull(db_row_normalized[col]) else str(db_row_normalized[col]).strip()
                    print("Database Columns:", database_table_df.columns)
                    excel_row_normalized[col] = excel_row_normalized[col] if pd.isnull(excel_row_normalized[col]) else str(excel_row_normalized[col]).strip()

                # Comparison logic
                significant_difference = False
                for column in ["title_of_order", "ROC_RD_LOCATION", "link_to_order"]:
                    db_value = db_row_normalized[column]
                    excel_value = excel_row_normalized[column]

                    if pd.isnull(db_value) and pd.isnull(excel_value):
                        continue

                    if isinstance(db_value, str):
                        db_value = db_value.strip()

                    if isinstance(excel_value, str):
                        excel_value = excel_value.strip()

                    if db_value != excel_value:
                        print(f"Difference found in column: {column}, db_value: {db_value}, excel_value: {excel_value}")
                        significant_difference = True
                        break

                if significant_difference:
                    updated_rows_in_db.append(db_row)
                    updated_rows_in_excel.append(excel_row)
                    
                    
        
        print("updated_rows_in_db===\n\n\n", updated_rows_in_db)
        print("updated_rows_in_excel===\n\n\n", updated_rows_in_excel)
        if len(updated_rows_in_db) > 0:
       
            count =updated_data_into_database_table(updated_rows_in_db, updated_rows_in_excel)
            mca_config.updated_count = count
            print("updated count========",mca_config.updated_count )    
